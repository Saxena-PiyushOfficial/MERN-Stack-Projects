function validateForm(event) {
  event.preventDefault(); // Prevent the form from submitting

  var participantName = document.getElementById("participantName").value;
  var email = document.getElementById("email").value;
  var confirmEmail = document.getElementById("confirmEmail").value;
  var seminar = document.getElementById("seminar").value;
  var level = document.getElementById("level").value;

  // Basic email validation
  var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email) || email !== confirmEmail) {
    alert("Invalid or mismatched email addresses");
    return false;
  }

  // Additional custom validation based on your requirements
  // For example, you can check if the participantName is not empty
  if (participantName.trim() === "") {
    alert("Please enter a valid participant name");
    return false;
  }

  // Calculate training cost based on seminar and level (replace this with your logic)
  var trainingCost = calculateTrainingCost(seminar, level);

  // Display the calculated training cost in the form
  document.getElementById("trainingCost").value = trainingCost;

  alert("All data entered correctly");
  return true; // Allow the form to submit
}

function calculateTrainingCost(seminar, level) {
  // Replace this with your actual cost calculation logic
  // You can use a lookup table or any other method based on your requirements
  var costTable = {
    SOA: { Introductory: 100, Intermediate: 150, Advanced: 200 },
    // Add other seminars and levels as needed
  };

  return costTable[seminar][level] || 0;
}

function displayDetails() {
  // Add logic to display participant details in a separate window or console
  var participantName = document.getElementById("participantName").value;
  var email = document.getElementById("email").value;
  var seminar = document.getElementById("seminar").value;
  var level = document.getElementById("level").value;
  var trainingCost = document.getElementById("trainingCost").value;

  var details =
    "Participant Name: " +
    participantName +
    "\n" +
    "Email: " +
    email +
    "\n" +
    "Seminar: " +
    seminar +
    "\n" +
    "Level: " +
    level +
    "\n" +
    "Training Cost: " +
    trainingCost;

  // Display in the console for demonstration purposes
  console.log(details);

  // You can use window.open() or any other method to display details in a new window
}
