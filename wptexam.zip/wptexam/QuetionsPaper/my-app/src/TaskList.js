import React from "react";

function TaskList({ tasks }) {
  return (
    <div className="task-list">
      <table>
        <thead>
          <tr>
            <th>Task Name</th>
            <th>Task Duration</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map((task, index) => (
            <tr key={index}>
              <td>{task.taskName}</td>
              <td>{task.taskDuration}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default TaskList;
