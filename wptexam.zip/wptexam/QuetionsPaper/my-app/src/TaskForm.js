import React, { useState } from "react";

function TaskForm({ addTask }) {
  const [taskName, setTaskName] = useState("");
  const [taskDuration, setTaskDuration] = useState("");

  const handleAddTask = () => {
    if (taskName && taskDuration) {
      addTask({ taskName, taskDuration });
      setTaskName("");
      setTaskDuration("");
    }
  };

  return (
    <div className="task-form">
      <label>
        Task Name:
        <input
          type="text"
          value={taskName}
          onChange={(e) => setTaskName(e.target.value)}
        />
      </label>
      <label>
        Task Duration:
        <input
          type="text"
          value={taskDuration}
          onChange={(e) => setTaskDuration(e.target.value)}
        />
      </label>
      <button onClick={handleAddTask}>Add List</button>
    </div>
  );
}

export default TaskForm;
