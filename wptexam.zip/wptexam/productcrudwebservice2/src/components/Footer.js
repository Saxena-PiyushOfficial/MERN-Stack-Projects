import './Footer.css'
const Footer=()=>{
   return (<h4 className="myc">&copy; copyrights reseved</h4>)
}

export default Footer;