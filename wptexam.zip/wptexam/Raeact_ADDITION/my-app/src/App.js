// App.js
import React from "react";
import SumComponent from "./SumComponent";

const App = () => {
  return (
    <div>
      <SumComponent />
    </div>
  );
};

export default App;
