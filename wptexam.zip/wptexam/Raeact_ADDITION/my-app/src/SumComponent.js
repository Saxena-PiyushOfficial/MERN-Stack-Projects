// SumComponent.js
import React, { useState } from "react";

const SumComponent = () => {
  const [number1, setNumber1] = useState("");
  const [number2, setNumber2] = useState("");
  const [sum, setSum] = useState("");

  const handleSum = () => {
    const num1 = parseFloat(number1);
    const num2 = parseFloat(number2);

    if (!isNaN(num1) && !isNaN(num2)) {
      const result = num1 + num2;
      setSum(result);
    } else {
      setSum("Invalid input. Please enter valid numbers.");
    }
  };

  return (
    <div>
      <h2>CDACA acts</h2>
      <div>
        <label htmlFor="number1">Number1:</label>
        <input
          type="text"
          id="number1"
          value={number1}
          onChange={(e) => setNumber1(e.target.value)}
        />
      </div>
      <div>
        <label htmlFor="number2">Number2:</label>
        <input
          type="text"
          id="number2"
          value={number2}
          onChange={(e) => setNumber2(e.target.value)}
        />
      </div>
      <button onClick={handleSum}>Ada</button>
      <div>
        <p>Sum is: {sum}</p>
      </div>
    </div>
  );
};

export default SumComponent;
